
<a name="StereoSID-2.0.7"></a>
## [StereoSID-2.0.7](https://github.com/daitangio/sid-arduino-lib/compare/StereoSID-2.0.6...StereoSID-2.0.7) (2023-11-12)

### Fix

* Fix: library now pass arduino lint checks

### Included

* Included original project license

### Merge

* Merge remote-tracking branch 'upstream/master'

### Updated

* Updated library.properties after proper testing with Arduino IDE 2.2.1

### Pull Requests

* Merge pull request [#3](https://github.com/daitangio/sid-arduino-lib/issues/3) from per1234/keywords_txt-multiple-tabs
* Merge pull request [#2](https://github.com/daitangio/sid-arduino-lib/issues/2) from per1234/keywords_txt-multiple-tabs


<a name="StereoSID-2.0.6"></a>
## [StereoSID-2.0.6](https://github.com/daitangio/sid-arduino-lib/compare/StereoSID-2.0.5...StereoSID-2.0.6) (2018-04-30)

### Typo

* Typo fixes


<a name="StereoSID-2.0.5"></a>
## [StereoSID-2.0.5](https://github.com/daitangio/sid-arduino-lib/compare/StereoSID-2.0.3...StereoSID-2.0.5) (2017-11-18)

### Updated

* Updated with a small introduction

### Pull Requests

* Merge pull request [#1](https://github.com/daitangio/sid-arduino-lib/issues/1) from per1234/add-category


<a name="StereoSID-2.0.3"></a>
## [StereoSID-2.0.3](https://github.com/daitangio/sid-arduino-lib/compare/StereoSID-2.0.2...StereoSID-2.0.3) (2015-04-09)

### Updated

* Updated library properties (missed url)


<a name="StereoSID-2.0.2"></a>
## [StereoSID-2.0.2](https://github.com/daitangio/sid-arduino-lib/compare/SID-2.0.1...StereoSID-2.0.2) (2015-04-01)


<a name="SID-2.0.1"></a>
## [SID-2.0.1](https://github.com/daitangio/sid-arduino-lib/compare/SID-2.0.0...SID-2.0.1) (2013-04-13)


<a name="SID-2.0.0"></a>
## SID-2.0.0 (2012-12-26)

